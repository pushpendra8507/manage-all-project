<?php  

include_once 'classes/startup.php';
$core = new Core;
$mv_welcome = new MV_Welcome;
$programes_data = new MV_Services;
$quality = new MV_Quality;
$pr_testimonials = new MV_Testimonials;
$gallery = new MV_Gallery;
$contactus = new MV_Contactus;


$contact = $contactus->index();
$testimonials = $pr_testimonials->index();
$welcome_data = $mv_welcome->index();
$services_data = $programes_data->index(2);
$quality_data = $quality->index(2);
$gallery_data = $gallery->index(2);
?>


<!-- Search Form -->
<div class="header-middle bg-white">
    <div class="container">
        <div class="logo-header">
            <a href="<?php echo SITEURL ?>">
                <img src="<?php echo SITEURL ?>images/renovadam-logo.png" alt="Professional Plumbing Services in Laval, QC" />
            </a>
        </div>
        <div class="header-info">
            <ul>
            	<li>
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-travel"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>Service Area </strong>
                            <span><a href="https://goo.gl/maps/x1kdnutao6BHKZFW9" target="_blank"><?php echo isset($contact['address'])? $contact['address']: '' ?></a></span>
                        </div>
                    </div>
                </li>
                <li>
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-smartphone-1"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>Call Us</strong>
                            <span><a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><?php echo isset($contact['phone'])? $contact['phone']: '' ?></a></span>
                        </div>
                    </div>
                </li>
                <li class="btn-col-last">
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-email"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>Opening Time </strong>
                            <span>Mon - Sun: 08:00 - 09:00 </span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<!-- Search Form -->
<div class="sticky-header main-bar-wraper">
    <div class="main-bar header-botton nav-bg-secondry">
        <div class="container">
            <!-- NAV Toggle Button -->
            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="request-button">
                <a href="<?php echo SITEURL ?>request-a-quote.php">Request a Quote</a>
            </div>
            
            <!-- MAIN Nav -->
            <div class="header-nav navbar-collapse collapse ">
                <ul class=" nav navbar-nav">
                    <li class="active"><a href="<?php echo SITEURL ?>">Home</a></li>
                    <li class=""><a href="<?php echo SITEURL ?>services.php">Services</a></li>
                    <li class=""><a href="<?php echo SITEURL ?>projects.php">Projects</a></li>
                    <li class=""><a href="<?php echo SITEURL ?>request-a-quote.php">Request a Quote</a></li>
                    <li class=""><a href="<?php echo SITEURL ?>contact-us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>