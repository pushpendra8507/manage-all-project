<?php  

include_once 'classes/startup.php';
$core = new Core;
$contactus = new MV_Contactus;
$contact = $contactus->index();

?>


<!-- FOOTER START -->
<footer class="site-footer footer-dark">
    <div class="footer-bottom overlay-wraper">
        <div class="overlay-main"></div>
        <div class="constrot-strip"></div>
        <div class="container p-t30">
            <div class="row">
                <div class="wt-footer-bot-left">
                    <span class="copyrights-text">© 2022 Renov Adam. All Rights Reserved.<br><a href="https://www.wxperts.co/website-development.php" target="_blank">Website Development</a> | <a href="https://www.wxperts.co/" target="_blank">Hosting</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Digital Marketing</a><br><a href="https://www.wxperts.co/" target="_blank"><img src="<?php echo SITEURL ?>images/wxperts_powerdby.jpg" alt="wxperts"></a></span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- FOOTER END -->


<!-- SCROLL TOP BUTTON -->
<button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>
<div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="<?php echo isset($contact['facebook'])? $contact['facebook']: '' ?>" title="Facebook" target="_blank">
                <img src="<?php echo SITEURL ?>images/fb.png" alt="Facebook">
                <p>Facebook</p>
            </a>
        </li>
        <li>
            <a href="<?php echo isset($contact['yelp'])? $contact['yelp']: '' ?>" title="Yelp" target="_blank">
                <img src="<?php echo SITEURL ?>images/yelp.png" alt="Yelp">
                <p>Yelp</p>
            </a>
        </li>
        <li>
            <a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>" title="Call Us">
                <img src="<?php echo SITEURL ?>images/call-icon.png" alt="Call Now">
                <p><?php echo isset($contact['phone'])? $contact['phone']: '' ?></p>
            </a>
        </li>
    </ul>
</div>

<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="<?php echo SITEURL ?>js/jquery-1.12.4.min.js"></script>
<script src="<?php echo SITEURL ?>js/bootstrap.min.js"></script>

<script src="<?php echo SITEURL ?>js/magnific-popup.min.js"></script>

<script src="<?php echo SITEURL ?>js/waypoints.min.js"></script>

<script src="<?php echo SITEURL ?>js/waypoints-sticky.min.js"></script>
<script src="<?php echo SITEURL ?>js/bootstrap-datepicker.js"></script>
<script>
    $(document).ready(function () {
        var dateToday = new Date();
        $('#booking_date').datepicker({                                     
            'startDate': dateToday,
            format: "dd/mm/yyyy"
        });
    });
</script>
<script src="<?php echo SITEURL ?>js/jquery.fancybox.js"></script>
<script>
  jQuery(document).ready(function($){   
    $('.fancybox').fancybox();
  });
</script>
<script src="<?php echo SITEURL ?>js/custom.js"></script>

</body>
</html>
