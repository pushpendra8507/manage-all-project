<?php  
include_once 'classes/startup.php';
$core = new Core;
?>
<!DOCTYPE html>
<html lang="en-US"> 
<head> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="icon/favicon-32x32.png" type="image/png" sizes="32x32">
<link rel="shortcut icon" href="icon/favicon-32x32.png" type="image/png" sizes="32x32">
<title>Renov Adam| Home Renovation Contractors in Laval, QC</title>
<meta name="description" content="Renov Adam provides Top Home Renovation Contractors in Laval, QC, and the surrounding areas. We also offer services such as Kitchen Renovation, bathroom renovation, plumbing, room additions, universal design, renovation services, and much more. Visit us for more info!">
<meta name="keywords" content="Professional Plumbing Services in Laval, QC, Painters in Laval, QC, Painting Services in Laval, QC, Kitchen Renovation in Laval, QC, Bathroom Renovation in Laval, QC, Renovation Services in Laval, QC, Exterior & Interior Painting in Laval, QC, Kitchen and Bathroom Renovation in Laval, QC, Basement Renovation in Laval, QC, Plastering Services in Laval, QC, Flooring Services in Laval, QC, Flooring Installation in Laval, QC, Renovation Contractor in Laval, QC, Home Remodeling in Laval, QC, Kitchen Remodeling in Laval, QC, Bathroom Remodeling in Laval, QC, Room Additions in Laval, QC, Cabinet Painting in Laval, QC, Exterior Painting in Laval, QC, Interior Painting in Laval, QC, Plaster & Drywall Services in Laval, QC, Ceiling & Wall Painting in Laval, QC, Hardwood Floor Installation in Laval, QC, Laminate Floor Installation in Laval, QC, Flooring Service in Laval, QC, Universal Design in Laval, QC, Construction Company in Laval, QC, Cabinetry Services in Laval, QC, Home Decor in Laval, QC, Plumbing Services in Laval, QC, Plumbing Repair in Laval, QC, Plumbing Service in Laval, QC, Bathroom Repair in Laval, QC, Plumbing Replacement in Laval, QC, Commercial Plumbing Services in Laval, QC, Commercial Plumbing Repair in Laval, QC, Interior & Exterior Paint  in Laval, QC, Painting Company in Laval, QC, Commercial Painting in Laval, QC, Residential Painting in Laval, QC, Professional Painting in Laval, QC, Painting Contractors in Laval, QC, House Painting in Laval, QC, Painting Renovations  in Laval, QC, Commercial Services in Laval, QC, Damage Restoration in Laval, QC, Electrical Services in Laval, QC, Door Services in Laval, QC, Home Building in Laval, QC, Windows Services in Laval, QC, Siding Services in Laval, QC, Residential Services in Laval, QC, Carpentry Services in Laval, QC, Renovation Contractors in Laval, QC, Kitchen Renovation Contractors in Laval, QC, Bathroom Renovation Contractors in Laval, QC, Home Renovation Company  in Laval, QC, Home Renovation Services in Laval, QC, Home Improvement Services in Laval, QC, Flooring Installations in Laval, QC, Commercial Renovation in Laval, QC, Home Improvement Company in Laval, QC, Interior Renovation in Laval, QC, Exterior Renovation in Laval, QC">

<!-- GOOGLE FONTS -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo SITEURL ?>css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo SITEURL ?>css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo SITEURL ?>css/flaticon.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo SITEURL ?>css/style.css">
<link rel="stylesheet" class="skin" type="text/css" href="<?php echo SITEURL ?>css/skin/skin-1.css">
<link rel="stylesheet" type="text/css" href="<?php echo SITEURL ?>css/jquery.fancybox.css?v=2.1.4" media="screen">
<style>.fancybox-custom .fancybox-skin{box-shadow: 0 0 50px #222;}</style>
<link rel="stylesheet" href="<?php echo SITEURL ?>css/datepicker.css">
<style>
    #dialog {clear:both;}
    #dialog p{
       
        color: #FF1632;
        font: 11px Geneva,Arial,Helvetica,sans-serif;
        margin: 0 5px;
        padding: 5px 5px 5px 25px;
        clear:both;
    }
</style>
<script src="component/jquery/jquery-3.2.1.min.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<!-- [if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
<![endif] -->
</head>
<body>