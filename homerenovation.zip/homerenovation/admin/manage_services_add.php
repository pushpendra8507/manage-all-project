<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$programes_data = new MV_Services;


if (isset($_POST['btn_submit'])) {

    $data['alias'] = (isset($_POST['title']) && !empty($_POST['title'])) ? $core->alias_url($_POST['title']) : '';
    $data['seo_title'] = (isset($_POST['seo_title']) && !empty($_POST['seo_title'])) ? ($_POST['seo_title']) : '';

    $data['seo_keyword'] = (isset($_POST['seo_keyword']) && !empty($_POST['seo_keyword'])) ? ($_POST['seo_keyword']) : '';
    $data['seo_description'] = (isset($_POST['seo_description']) && !empty($_POST['seo_description'])) ? $_POST['seo_description'] : '';
    $data['seo_h1'] = (isset($_POST['seo_h1']) && !empty($_POST['seo_h1'])) ? ($_POST['seo_h1']) : '';
    $data['seo_h2'] = (isset($_POST['seo_h2']) && !empty($_POST['seo_h2'])) ? ($_POST['seo_h2']) : '';
    $data['title'] = (isset($_POST['title']) && !empty($_POST['title'])) ? $_POST['title'] : '';
    $data['description'] = (isset($_POST['description']) && !empty($_POST['description'])) ? $_POST['description'] : '';

    $data['alt_name'] = (isset($_POST['alt_name']) && !empty($_POST['alt_name'])) ? $_POST['alt_name'] : '';




    if (empty($_POST['status'])) {
        $last_insert_id = $programes_data->store($data);
    } else {
        $last_insert_id = $programes_data->update($_POST['status'], $data);
    }

    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $last_insert_id > 0) {
        $path = '../uploads/';
        $core->UploadImage($_FILES['fu_photo'], $path, 'dbblackcar' . time() . $last_insert_id, 'tbl_services', 'photourl', 'id', $last_insert_id);
    }



    if ($last_insert_id > 0) {
        if (!empty($_POST['status'])) {
            $alert_data = array(
                "status" => "Record Updated",
                "icon" => "success",
                "page_url" => "manage_services.php"
            );
        } else {
            $alert_data = array(
                "status" => "Record Added",
                "icon" => "success",
                "page_url" => "manage_services.php"
            );
        }
    } else {
        $alert_data = array(
            "status" => "something went wrong",
            "icon" => "error",
            "page_url" => "manage_services.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

if (isset($_REQUEST["eid"])) {
    $details = $programes_data->get_details($_REQUEST["eid"]);
}



$page_name = 'services';

include("includes/top_header.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_services.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    <?php echo isset($_REQUEST['eid']) ? "Edit" : "Add"; ?>
                    Services
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" name="status" value="<?php echo (isset($_REQUEST['eid'])) ? $_REQUEST['eid'] : ""; ?>">
                        <div class="col-md-12">

                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Seo Title </label>
                                    <textarea class="form-control" name="seo_title"><?php echo isset($details['seo_title']) ? html_entity_decode($details['seo_title']) : '' ?></textarea>
                                </div>
                            </div>  -->


                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Seo Keyword </label>
                                    <textarea class="form-control" name="seo_keyword"><?php echo isset($details['seo_keyword']) ? html_entity_decode($details['seo_keyword']) : '' ?></textarea>
                                </div>
                            </div> -->


                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Seo Description </label>
                                    <textarea class="form-control " name="seo_description"><?php echo isset($details['seo_description']) ? html_entity_decode($details['seo_description']) : '' ?></textarea>
                                </div>
                            </div>  -->

                            <!-- <div class="col-md-12" style="margin-bottom: 32px;">
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <label for="inputEmail3"> Seo H1 </label>
                                        <textarea class="form-control" name="seo_h1"><?php echo isset($details['seo_h1']) ? html_entity_decode($details['seo_h1']) : '' ?></textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="inputEmail3"> Seo H2 </label>
                                        <textarea class="form-control" name="seo_h2"><?php echo isset($details['seo_h2']) ? html_entity_decode($details['seo_h2']) : '' ?></textarea>
                                    </div>
                                </div>
                            </div> -->


                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Title </label>
                                    <input type="text" name="title" value="<?php echo (isset($details['title'])) ? $details['title'] : ''; ?>" required="" class="form-control" id="inputEmail3">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Long Description of Services Page </label>
                                    <textarea class="form-control description" name="description"><?php echo isset($details['description']) ? html_entity_decode($details['description']) : '' ?></textarea>
                                </div>
                            </div>

                           <div class="col-md-6">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image</label>
                                    <input type="file" name="fu_photo" id="image" />
                                </div>
                                <div class="col-md-6">
                                    <img width="60" style="border-radius:10%" id="showImage" src="<?php echo (!empty($details['photourl'])) ? '../' . $details['photourl'] : '' ?>" />
                                </div>
                            </div>

                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Alt_Name </label>
                                    <input type="text" name="alt_name" value="<?php echo (isset($details['alt_name'])) ? $details['alt_name'] : ''; ?>" required="" class="form-control" id="inputEmail3">
                                </div>
                            </div> -->
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>

</body>

</html>