<footer class="footer left">
	<center>Copyright © 2023 <?php echo ADMIN_TITLE; ?>. All Rights Reserved.<br>
		<a href="https://www.wxperts.co/" target="_blank">
			<img src="images/wxperts_powerdby.jpg" alt="wxperts">
		</a>
	</center>
</footer>
<script src="js/sweetalert.min.js"></script>
<script src="cleditor/jquery.cleditor.min.js"></script>
<script src="cleditor/jquery.cleditor.table.min.js"></script>
<script type="text/javascript">
	$(document).ready(function () { $(".description").cleditor(); });
</script>
<?php
echo $core->show_sweetalert();
?>

