<?php
include("includes/top-header.php");
?>

<div class="page-wraper">
    	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="./projects.php">French</a></li>
                            <li><a href="../projects.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
    	<!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/background/all.jpg);">
        	<div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Projets</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
        	<div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="./"><i class="fa fa-home"></i> Accueil</a></li>
                    <li>Projets</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->         
    
        <!-- SECTION CONTENT -->
        <div class="projects-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li>
                                <a href="images/gal/1.jpg" title="Cuisines" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/1.jpg" alt="Cuisines">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/2.jpg" title="Cuisines" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/2.jpg" alt="Cuisines">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/3.jpg" title="Cuisines" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/3.jpg" alt="Cuisines">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/4.jpg" title="Cuisines" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/4.jpg" alt="Cuisines">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/5.jpg" title="Cuisines" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/5.jpg" alt="Cuisines">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/6.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/6.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/7.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/7.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/8.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/8.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/9.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/9.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/10.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/10.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/11.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/11.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/12.jpg" title="Salles de bain" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/12.jpg" alt="Salles de bain">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/13.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/13.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/14.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/14.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/15.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/15.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/16.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/16.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/17.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/17.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/18.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/18.jpg" alt="Sol">
                                </a>
                            </li>
                            <li>
                                <a href="images/gal/19.jpg" title="Sol" class="fancybox" data-fancybox-group="gallery">
                                    <img src="images/gal/19.jpg" alt="Sol">
                                </a>
                            </li>
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
        <!-- SECTION CONTENT END -->
    </div>
    <!-- CONTENT END -->
</div>
<?php include("includes/footer.php"); ?>