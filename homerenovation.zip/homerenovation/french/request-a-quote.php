<?php
include("includes/top-header.php");

define('SITE_KEY',"6Ld6P9kZAAAAAIizTWnp0Yb7VaVGe3rsKBY7J4j8"); 
define('SECRET_KEY',"6Ld6P9kZAAAAACchvWVlKg6YFPqbqbDyPoFGv24x");

if (isset($_POST['btn_submit'])) {
    
    if (isset($_POST['g-recaptcha-response'])) {
	
	require('component/recaptcha/src/autoload.php');        
	
	$recaptcha = new \ReCaptcha\ReCaptcha(SECRET_KEY);
	
	$resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
	
	if (!$resp->isSuccess()) {
	    $output = json_encode(array('type'=>'error', 'text' => '<b>Captcha</b> Validation Required!'));
	    die($output);               
	} 
        
    $here_about = htmlspecialchars(stripslashes(trim($_POST['here_about_us'])));
    $name = htmlspecialchars(stripslashes(trim($_POST['name'])));
    $email = htmlspecialchars(stripslashes(trim($_POST['email'])));
    $phone = htmlspecialchars(stripslashes(trim($_POST['phone'])));
    $address = htmlspecialchars(stripslashes(trim($_POST['address'])));
    $city = htmlspecialchars(stripslashes(trim($_POST['city'])));
    $state = htmlspecialchars(stripslashes(trim($_POST['state'])));
    $zipcode = htmlspecialchars(stripslashes(trim($_POST['zipcode'])));
    $booking_date = $_POST['booking_date'];
    $time = htmlspecialchars(stripslashes(trim($_POST['time'])));
    $msge = htmlspecialchars(stripslashes(trim($_POST['message'])));

    $restriction = array(' sex ', ' fuck ', ' ass ', ' bonk ', ' blow ', ' lie ', ' cryptocurrency ', ' web developer ', ' developer ', ' designer ', ' ideas ',
        ' crypto currency ', ' bitcoin ', ' website ', ' need ', ' freelance ', ' better ', ' previous ', ' wont ', ' fees ', ' CryptoTab ',
        ' best ', ' appreciate ', ' cheers ', ' sites ', ' search engine ', ' visitors ', ' marketing ', ' money ', ' users ', ' improvements ',
        ' unlock ', ' hot ', ' talkwithcustomer ', ' traffic ', ' work ', ' social media ', ' blog ', ' liveserveronline ', ' buy ', ' seo ', ' monkeydigital ',
        ' digital ', ' improve ', ' offer ', ' job ', ' sales ', ' surfing ', ' casino ', ' prophecy ', ' church ', ' indeed ', ' god ', ' falling ', ' Advisors ',
        ' loan ', ' Eligibility ', ' suggest ', ' https ', ' adultdating ', ' dating ', ' 1borsa ', ' nuratina ', ' links ');
    foreach ($restriction as $restrictions) {

        if (stripos($msge, $restrictions) !== false) {
            echo '<script>alert("abusive word found");window.location="request-a-quote.php"</script>';
            exit;
        }
    }

    

    $to = 'moh_graphics@live.ca';
    //$to = 'ram.sharan@wserve.com'; // add additional mail receipient here
    $fromMail = $email;
    $fromName = 'RenovAdam';
    $subject = 'Request a Quote';
    $message = '<html><head><title>RenovAdam</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
    <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

    <tr bgcolor="#000" valign="top">
    <td height="25"  colspan="2" style="font:bold 21px  Arial, Helvetica, sans-serif; color:#fff"><center>RenovAdam</center></td>
    </tr>
    </table>
    <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
    <tbody>
    <tr>
    <td width="100%" valign="top">
    <table width="100%" cellspacing="3" cellpadding="5" border="1" >
    <tbody>     
    <tr bgcolor="#000">
    <td colspan="2" class="billing_hd" style="color:#FFF"><strong>Request a Quote</strong></td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Hear about us?:</td>
    <td width="70%" class="ship_dt">' . $here_about . '</td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Name:</td>
    <td width="70%" class="ship_dt">' . $name . '</td>
    </tr>
    <tr>
    <td class="ship_hd">Phone:</td>
    <td class="ship_dt">' . $phone . '</td>
    </tr>
    <tr>
    <td class="ship_hd">Email:</td>
    <td class="ship_dt">' . $email . '</td>
    </tr>
    <tr>
    <td class="ship_hd">Address:</td>
    <td class="ship_dt">' . $address . '</td>
    </tr>
    <tr>
    <td class="ship_hd">City:</td>
    <td class="ship_dt">' . $city . '</td>
    </tr>
    <tr>
    <td class="ship_hd">State:</td>
    <td class="ship_dt">' . $state. '</td>
    </tr>
    <tr>
    <td class="ship_hd">Zip Code:</td>
    <td class="ship_dt">' . $zipcode . '</td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Date:</td>
    <td width="70%" class="ship_dt">' . $booking_date . '</td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Time:</td>
    <td width="70%" class="ship_dt">' . $time . '</td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Message:</td>
    <td width="70%" class="ship_dt">' . $msge . '</td>
    </tr>
    </table>
    </td>
    </tr></tbody>
    </table>
    </div></body></html>';
    // To send HTML mail, the Content-type header must be set
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $headers .= 'Bcc: info@wserve.com' . "\r\n";
    //$headers .= 'Bcc: rahul.chhabra@wserve.com' . "\r\n";
    //$headers .= 'Bcc: ram.sharan@wserve.com' . "\r\n";
    $message = str_replace("\'", "'", $message);
    //echo $message;exit;
    $send_mail = mail($to, $subject, $message, $headers);

    if ($send_mail) {
        echo '<script>alert("Thank You.");window.location="request-a-quote.php"</script>';
    } else {
        echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="request-a-quote.php"</script>';
    }
}
else {
        echo '<script> alert("Invalid Captcha !");window.location="request-a-quote.php"</script>';
    }

}
?>

<div class="page-wraper">
    	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="./request-a-quote.php">French</a></li>
                            <li><a href="../request-a-quote.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
    	<!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/background/all.jpg);">
        	<div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Demander un devis</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
        	<div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="./"><i class="fa fa-home"></i> Accueil</a></li>
                    <li>Demander un devis</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->         
    
        <!-- SECTION CONTENT -->
        <div class="request-a-quote-form">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12"> 
                        <div class="appointment-form-wrapper light-layout margin-bottom-24 clearfix">
                            <form method="post" class="appoinment-form"> 

                                <div class="form-group col-md-6">
                                    <label for="your_phone">Comment avez-vous entendu parler de nous?:</label>
                                    <select name="here_about_us">
                                        <option value="Associé en magasin">Associé en magasin</option>
                                        <option value="Des médias sociaux">Des médias sociaux</option>
                                        <option value="Référence personnelle">Référence personnelle</option>
                                        <option value="Google AdWords">Google AdWords</option>
                                        <option value="Recommandation d'un ami">Recommandation d'un ami</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_name">Nom: </label>
                                    <input id="your_name" class="form-control" type="text" name="name" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_name">Email: </label>
                                    <input id="your_email" class="form-control" type="email" name="email" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_name">Téléphone: </label>
                                    <input id="your_email" class="form-control" type="text" name="phone" required="" data-msg="This field is required.">
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="your_phone">Adresse: </label>
                                    <input id="your_phone" class="form-control" type="text" name="address" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_phone">Ville: </label>
                                    <input id="your_phone" class="form-control" type="text" name="city" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_phone">Etat: </label>
                                    <input id="your_phone" class="form-control" type="text" name="state" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_phone">Code postal: </label>
                                    <input id="your_phone" class="form-control" type="text" name="zipcode" required="" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_phone">Date: </label>
                                    <input type="text" class="form-control" placeholder="Click to Show Date" required="" id="booking_date" name="booking_date" data-msg="This field is required.">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="your_phone">Temps: </label>
                                    <select name="time">
                                        <option selected>Sélectionnez l'heure</option>
                                        <option value="09:00AM">09:00AM</option>
                                        <option value="09:30AM">09:30AM</option>
                                        <option value="10:00AM">10:00AM</option>
                                        <option value="10:30AM">10:30AM</option>
                                        <option value="11:00AM">11:00AM</option>
                                        <option value="11:30AM">11:30AM</option>
                                        <option value="12:00PM">12:00PM</option>
                                        <option value="12:30PM">12:30PM</option>
                                        <option value="01:00PM">01:00PM</option>
                                        <option value="01:30PM">01:30PM</option>
                                        <option value="02:00PM">02:00PM</option>
                                        <option value="02:30PM">02:30PM</option>
                                        <option value="03:00PM">03:00PM</option>
                                        <option value="03:30PM">03:30PM</option>
                                        <option value="04:00PM">04:00PM</option>
                                        <option value="04:30PM">04:30PM</option>
                                        <option value="05:00PM">05:00PM</option>
                                        <option value="05:30PM">05:30PM</option>
                                        <option value="06:00PM">06:00PM</option>
                                        <option value="06:30PM">06:30PM</option>
                                    </select>
                                </div>

                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <label for="textarea_message">Veuillez fournir une brève description du projet souhaité: </label>
                                    <textarea id="textarea_message" name="message" class="form-control" rows="4" required="" data-msg="This field is required."></textarea>
                                </div>  
                                <div class="form-group col-md-6">
                                    <div class="g-recaptcha" data-sitekey="<?php echo SITE_KEY; ?>" required=""></div>
                                </div>
                                 
                                <div class="form-group col-md-12 col-sm-12 col-xs-12 text-left">
                                    <button id="btn_submit" class="btn btn-lg btn-theme btn-square btn-theme-invert" type="submit" name="btn_submit">Envoyer ma demande</button>
                                </div>
                            </form>
                        </div>
                    </div>   
                </div>
            </div>
        </div>
        <!-- SECTION CONTENT END -->
    </div>
    <!-- CONTENT END -->
</div>
<?php include("includes/footer.php"); ?>