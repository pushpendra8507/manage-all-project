<!-- Search Form -->
<div class="header-middle bg-white">
    <div class="container">
        <div class="logo-header">
            <a href="./">
                <img src="images/renovadam-logo.png" alt="Renov Adam" />
            </a>
        </div>
        <div class="header-info">
            <ul>
                <li>
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-travel"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>ZONE DE SERVICE</strong>
                            <span><a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></span>
                        </div>
                    </div>
                </li>
                <li>
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-smartphone-1"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>Appelez-nous</strong>
                            <span><a href="tel:5147929517">(514) 792-9517</a></span>
                        </div>
                    </div>
                </li>
                <li class="btn-col-last">
                    <div>
                        <div class="icon-sm">
                            <span class="icon-cell  text-primary"><i class="iconmoon-email"></i></span>
                        </div>
                        <div class="icon-content">
                            <strong>Horaire d'ouverture </strong>
                            <span>Mon - Sun: 08:00 - 09:00 </span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<!-- Search Form -->
<div class="sticky-header main-bar-wraper">
    <div class="main-bar header-botton nav-bg-secondry">
        <div class="container">
            <!-- NAV Toggle Button -->
            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="request-button">
                <a href="request-a-quote.php">Demander un devis</a>
            </div>
            
            <!-- MAIN Nav -->
            <div class="header-nav navbar-collapse collapse ">
                <ul class=" nav navbar-nav">
                    <li class="active"><a href="./">Accueil</a></li>
                    <li class=""><a href="services.php">Prestations de service</a></li>
                    <li class=""><a href="projects.php">Projets</a></li>
                    <li class=""><a href="request-a-quote.php">Demander un devis</a></li>
                    <li class=""><a href="contact-us.php">Nous contacter</a></li>
                </ul>
            </div>
        </div>
    </div>
</div> 