<!-- FOOTER START -->
<footer class="site-footer footer-dark">
    <div class="footer-bottom overlay-wraper">
        <div class="overlay-main"></div>
        <div class="constrot-strip"></div>
        <div class="container p-t30">
            <div class="row">
                <div class="wt-footer-bot-left">
                    <span class="copyrights-text">© 2020 Renov Adam. Tous les droits sont réservés.<br><a href="https://www.wxperts.co/website-development.php" target="_blank">Développement de site Web</a> | <a href="https://www.wxperts.co/" target="_blank">Hébergement</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Le marketing numérique</a><br><a href="https://www.wxperts.co/" target="_blank"><img src="images/wxperts_powerdby.jpg" alt="wxperts"></a></span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- FOOTER END -->


<!-- SCROLL TOP BUTTON -->
<button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>
<div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/RenovadamLavalQC/?modal=admin_todo_tour" title="Facebook" target="_blank">
                <img src="images/fb.png" alt="Facebook">
                <p>Facebook</p>
            </a>
        </li>
        <li>
            <a href="https://www.yelp.com/biz/admar-renovations-montr%C3%A9al" title="Yelp" target="_blank">
                <img src="images/yelp.png" alt="Yelp">
                <p>Japper</p>
            </a>
        </li>
        <li>
            <a href="tel:5147929517" title="Call Us">
                <img src="images/call-icon.png" alt="Call Now">
                <p>(514) 792-9517</p>
            </a>
        </li>
    </ul>
</div>

<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/magnific-popup.min.js"></script>

<script src="js/waypoints.min.js"></script>

<script src="js/waypoints-sticky.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script>
    $(document).ready(function () {
        var dateToday = new Date();
        $('#booking_date').datepicker({                                     
            'startDate': dateToday,
            format: "dd/mm/yyyy"
        });
    });
</script>
<script src="js/jquery.fancybox.js"></script>
<script>
  jQuery(document).ready(function($){   
    $('.fancybox').fancybox();
  });
</script>
<script src="js/custom.js"></script>

</body>
</html>
