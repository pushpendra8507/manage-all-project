<!DOCTYPE html>
<html lang="en-US"> 
<head> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Renov Adam</title>
<meta name="description" content="Renov Adam">
<meta name="keywords" content="Renov Adam">

<!-- GOOGLE FONTS -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css?v=2.1.4" media="screen">
<style>.fancybox-custom .fancybox-skin{box-shadow: 0 0 50px #222;}</style>
<link rel="stylesheet" href="css/datepicker.css">
<style>
    #dialog {clear:both;}
    #dialog p{
        
        color: #FF1632;
        font: 11px Geneva,Arial,Helvetica,sans-serif;
        margin: 0 5px;
        padding: 5px 5px 5px 25px;
        clear:both;
    }
</style>
<script src="component/jquery/jquery-3.2.1.min.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<!-- [if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
<![endif] -->
</head>
<body>