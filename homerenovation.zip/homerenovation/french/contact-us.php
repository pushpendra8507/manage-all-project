<?php
 
    define('SITE_KEY',"6Ld6P9kZAAAAAIizTWnp0Yb7VaVGe3rsKBY7J4j8"); 
define('SECRET_KEY',"6Ld6P9kZAAAAACchvWVlKg6YFPqbqbDyPoFGv24x");

if (isset($_POST['btn_submit'])) {
       if (isset($_POST['g-recaptcha-response'])) {

        require('component/recaptcha/src/autoload.php');        

        $recaptcha = new \ReCaptcha\ReCaptcha(SECRET_KEY);

        $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

        if (!$resp->isSuccess()) {
            $output = json_encode(array('type'=>'error', 'text' => '<b>Captcha</b> Validation Required!'));
            die($output);               
        }
        
    $name = htmlspecialchars(stripslashes(trim($_POST['name'])));
    $email = htmlspecialchars(stripslashes(trim($_POST['email'])));
    $phone = htmlspecialchars(stripslashes(trim($_POST['phone'])));
    $msge = htmlspecialchars(stripslashes(trim($_POST['message'])));

    $restriction = array(' sex ', ' fuck ', ' ass ', ' bonk ', ' blow ', ' lie ', ' cryptocurrency ', ' web developer ', ' developer ', ' designer ', ' ideas ',
        ' crypto currency ', ' bitcoin ', ' website ', ' need ', ' freelance ', ' better ', ' previous ', ' wont ', ' fees ', ' CryptoTab ',
        ' best ', ' appreciate ', ' cheers ', ' sites ', ' search engine ', ' visitors ', ' marketing ', ' money ', ' users ', ' improvements ',
        ' unlock ', ' hot ', ' talkwithcustomer ', ' traffic ', ' work ', ' social media ', ' blog ', ' liveserveronline ', ' buy ', ' seo ', ' monkeydigital ',
        ' digital ', ' improve ', ' offer ', ' job ', ' sales ', ' surfing ', ' casino ', ' prophecy ', ' church ', ' indeed ', ' god ', ' falling ', ' Advisors ',
        ' loan ', ' Eligibility ', ' suggest ', ' https ', ' adultdating ', ' dating ', ' 1borsa ', ' nuratina ', ' links ');
    foreach ($restriction as $restrictions) {

        if (stripos($msge, $restrictions) !== false) {
            echo '<script>alert("abusive word found");window.location="contact-us.php"</script>';
            exit;
        }
    }

    $to = 'moh_graphics@live.ca';
    //$to = 'ram.sharan@wserve.com'; // add additional mail receipient here
    $fromMail = $email;
    $fromName = 'RenovAdam';
    $subject = 'Contact Form';
    $message = '<html><head><title>RenovAdam</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
    <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

    <tr bgcolor="#000" valign="top">
    <td height="25"  colspan="2" style="font:bold 21px  Arial, Helvetica, sans-serif; color:#fff"><center>RenovAdam</center></td>
    </tr>
    </table>
    <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
    <tbody>
    <tr>
    <td width="100%" valign="top">
    <table width="100%" cellspacing="3" cellpadding="5" border="1" >
    <tbody>     
    <tr bgcolor="#000">
    <td colspan="2" class="billing_hd" style="color:#FFF"><strong>Contact Form</strong></td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Name:</td>
    <td width="70%" class="ship_dt">' . $name . '</td>
    </tr>
    <tr>
    <td class="ship_hd">Email:</td>
    <td class="ship_dt">' . $email . '</td>
    </tr>
    <tr>
    <td class="ship_hd">Phone:</td>
    <td class="ship_dt">' . $phone . '</td>
    </tr>
    <tr>
    <td width="30%" class="ship_hd">Message:</td>
    <td width="70%" class="ship_dt">' . $msge . '</td>
    </tr>
    </table>
    </td>
    </tr></tbody>
    </table>
    </div></body></html>';
    // To send HTML mail, the Content-type header must be set
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $headers .= 'Bcc: info@wserve.com' . "\r\n";
    //$headers .= 'Bcc: rahul.chhabra@wserve.com' . "\r\n";
    //$headers .= 'Bcc: ram.sharan@wserve.com' . "\r\n";
    $message = str_replace("\'", "'", $message);
    //echo $message;exit;
    $send_mail = mail($to, $subject, $message, $headers);

    if ($send_mail) {
        echo '<script>alert("Thank You.");window.location="contact-us.php"</script>';
    } else {
        echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="contact-us.php"</script>';
    }
}
else {
        echo '<script> alert("Invalid Captcha !");window.location="contact-us.php"</script>';
    }
}
    include("includes/top-header.php");
?>

<div class="page-wraper">  
  	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href=".//contact-us.php">French</a></li>
                            <li><a href="../contact-us.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
        <!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/background/all.jpg);">
            <div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Nous contacter</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
            <div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="./"><i class="fa fa-home"></i> Accueil</a></li>
                    <li>Nous contacter</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->  
         
        <!-- SECTION CONTENTG START -->
        <div class="section-full p-t80 p-b50">
            <div class="container">
            
            	<!-- CONTACT DETAIL BLOCK -->
                <div class="section-content contact-info m-b30">

                    <div class="row">
                        <div class="col-md-4 col-sm-12 m-b30">
                            <div class="wt-icon-box-wraper center p-a30 bg-secondry">
                                <div class="icon-sm text-white m-b10"><i class="iconmoon-travel"></i></div>
                                <div class="icon-content">
                                    <h5>Informations d'adresse</h5>
                                    <p>Laval, QC</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 m-b30">
                            <div class="wt-icon-box-wraper center p-a30 bg-secondry">
                                <div class="icon-sm text-white m-b10"><i class="iconmoon-smartphone-1"></i></div>
                                <div class="icon-content">
                                    <h5>Numéro de téléphone</h5>
                                    <p>(514) 792-9517</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 m-b30">
                            <div class="wt-icon-box-wraper center p-a30 bg-secondry">
                                <div class="icon-sm text-white m-b10"><i class="iconmoon-email"></i></div>
                                <div class="icon-content">
                                    <h5>Email</h5>
                                    <p>moh_graphics@live.ca</p>
                                </div>
                            </div>
                        </div>
                    
                    </div>
      
                </div>
                
                <!-- GOOGLE MAP & CONTACT FORM -->
                <div class="section-content m-b50">
                    <div class="row">

                        <!-- CONTACT FORM-->
                        <div class="wt-box col-md-6">
                        
                            <h4 class="text-uppercase">Formulaire de contact </h4>
                            <div class="wt-separator-outer m-b30">
                                <div class="wt-separator style-square">
                                   <span class="separator-left bg-primary"></span>
                                   <span class="separator-right bg-primary"></span>
                                </div>
                                
                            </div>
                        
                        	<div class="p-a30 bg-gray">
                        
                                <form class="cons-contact-form" method="post">
                        
                                    <div class="row">
                                    
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                    <input name="name" type="text" required class="form-control" placeholder="Nom">
                                                </div>
                                            </div>
                                        </div>
        
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                    <input name="email" type="email" class="form-control" required placeholder="Email">
                                                </div>
                                            </div>
        
                                        </div>
        
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                                    <input name="phone" type="text" class="form-control" required placeholder="Pas de téléphone">
                                                </div>
                                            </div>
        
                                        </div>
        
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon v-align-t"><i class="fa fa-pencil"></i></span>
                                                    <textarea name="message" rows="1" class="form-control " required placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="g-recaptcha" data-sitekey="<?php echo SITE_KEY; ?>" required=""></div>
                                                </div>
                                            </div>
                                        </div>
        
                                        <div class="col-md-12">
                                            <button name="btn_submit" type="submit" value="Submit" class="site-button  m-r15">Soumettre  <i class="fa fa-angle-double-right"></i></button>
                                            <button name="Resat" type="reset" value="Reset"  class="site-button " >Réinitialiser  <i class="fa fa-angle-double-right"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    
                        <!-- LOCATION BLOCK-->
                        <div class="wt-box col-md-6">
                             <h4 class="text-uppercase">Emplacement</h4>
                            <div class="wt-separator-outer m-b30">
                               <div class="wt-separator style-square">
                                   <span class="separator-left bg-primary"></span>
                                   <span class="separator-right bg-primary"></span>
                               </div>
                           </div>      
                            <div class="map-g m-b30">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d357280.1227187574!2d-73.98969061369291!3d45.60560054676622!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc92107b4dfda6b%3A0x2eb4b26fe333c419!2sLaval%2C%20QC%2C%20Canada!5e0!3m2!1sen!2sin!4v1602879043969!5m2!1sen!2sin"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>