<?php
include("includes/top-header.php");
?>

<div class="page-wraper">
    	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="./services.php">French</a></li>
                            <li><a href="../services.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
    	<!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/background/all.jpg);">
        	<div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Prestations de service</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
        	<div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="./"><i class="fa fa-home"></i> Accueil</a></li>
                    <li>Prestations de service</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->         
    
        <!-- SECTION CONTENT -->
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv1.jpg" alt="Ajouts">
                        <h2>Ajouts</h2>
                        <p>L'ajout d'un ajout est un moyen simple d'améliorer votre maison. Avec RenovAdam à vos côtés, c'est encore plus facile. Après avoir établi les plans d'étage et rempli tous les documents requis au service de construction de votre ville, RenovAdam peut commencer les travaux. C'est un processus plein de décisions passionnantes car vous allez rénover votre maison. Si vous êtes prêt à vivre la magie d'un projet de construction, planifiez une estimation gratuite dès aujourd'hui!</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv2.jpg" alt="Sol">
                        <h2>Sol</h2>
                        <p>Nous savons que les revêtements de sol constituent la base de tout ce que vous faites chaque jour. C'est le sol solide sous vos pieds, le premier plan ou l'arrière-plan de chaque image à l'intérieur, un espace qui peut facilement passer inaperçu, mais c'est l'épine dorsale de la création d'un espace confortable pour vous et votre famille. Chez RenovAdam, nous savons à quel point chaque détail de votre maison est important pour vous. Nous employons des maîtres artisans et artisans pour poser avec précision les meilleurs carreaux de sol, tisser des bois durs de qualité et / ou choisir et installer le revêtement de sol en vinyle de luxe parfait pour s'adapter à votre espace et à vos besoins. Consultez notre portefeuille ci-dessous pour voir certains de nos travaux sur les revêtements de sol.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv3.jpg" alt="Conception universelle">
                        <h2>Conception universelle</h2>
                        <p>Créer le bon espace pour vous-même ou votre proche peut faire toute la différence. Nous pouvons vous fournir un espace de vie accessible aux fauteuils roulants sans obstacle pour répondre aux besoins de tous les types de capacités. Nous pouvons travailler avec vous pour déterminer vos besoins et créer un chef-d'œuvre de qualité, de design et de fonctionnalité. Cliquez sur un album ci-dessous pour voir certains de nos travaux utilisant Universal Design.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv4.jpg" alt="Salles de bain">
                        <h2>Salles de bain</h2>
                        <p>Il y a deux raisons de faire rénover votre salle de bain: 1) votre salle de bain n'a pas l'apparence que vous aimeriez ou 2) elle n'a pas été construite pour durer en premier lieu. Pour la première raison, les gens disent généralement que ce n’est pas si important que cela, si c’est fonctionnel, c’est bien. Mais pensez-y, la personne moyenne passe plus d'un an et demi dans la salle de bain au cours de sa vie. Compte tenu de cela, il n’est pas surprenant que tant de gens souhaitent que leur salle de bain soit agréable à regarder, car c’est une chance de s’éloigner du quotidien.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv5.jpg" alt="Cuisine">
                        <h2>Cuisine</h2>
                        <p>RenovAdam fournit des services de construction, d'ébénisterie et de conception de qualité supérieure pour la rénovation et la rénovation de cuisines depuis 2005. Nous coordonnons et gérons la construction, la commande et l'installation. Nous aidons les propriétaires à profiter davantage de leur maison avec de nouveaux modèles de cuisine qui se marient à merveille avec leur décoration intérieure nouvelle ou existante.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv6.jpg" alt="Plomberie">
                        <h2>Plomberie </h2>
                        <p>La prochaine fois que vous aurez besoin de services de plomberie ou que vous aurez un projet de réparation de plomberie à Laval, QC, vous pourrez compter sur les services de RenovAdam. Nous desservons Laval, au Québec depuis 2005 et nous nous sommes bâtis une réputation de service de plomberie le plus soigné, le plus professionnel et le plus digne de confiance. Nous pouvons prendre en charge les installations pour les rénovations de votre salle de bain, les réparations en cas de fuite ou de rupture, les remplacements de plomberie lorsque vient le temps d'une mise à niveau et tous vos besoins de plomberie réguliers et d'urgence. Nous offrons également des services d'experts en plomberie commerciale.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="images/serv7.jpg" alt="La peinture">
                        <h2>Peinture: extérieur et intérieur</h2>
                        <p>Votre communauté a-t-elle besoin d'un nouveau travail de peinture intérieure ou extérieure? Si c'est le cas, vous êtes au bon endroit. Nous avons une vaste expérience dans la peinture de propriétés multifamiliales et commerciales. RenovAdam Peinture et Rénovations a un processus qui a fait ses preuves. Au cours des 15 dernières années, nous avons servi des clients de toutes tailles et de tous besoins. Il y a de nombreux avantages à peindre votre propriété et nous avons l'expertise pour nous assurer que vous maximisez votre investissement. Nos services de peinture sont utilisés par une variété de clients, y compris des propriétés multifamiliales, commerciales, résidentielles et uniques. Nous offrons la peinture extérieure et intérieure, le lavage sous pression et la teinture. De plus, nous pouvons utiliser des revêtements de protection pour protéger davantage votre propriété des éléments. Si vous souhaitez parler à un représentant ou en savoir plus, n'hésitez pas à nous appeler.</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- SECTION CONTENT END -->
    
        <section class="service-list-page">
            <div class="container">
                <div class="row">
                    
                </div>
                <div class="row">
                    <div class="col-md-8 service-list">
                        <div class="col-md-12 col-sm-12 text-center">
                            <h3>NOUS OFFRONS DIVERS SERVICES INCLUANT:</h3>
                        </div>
                        <ul>
                            <li>Remodelage de la salle de bain</li>
                            <li>Ébénisterie</li>
                            <li>Charpenterie</li>
                            <li>Services commerciaux</li>
                            <li>Béton et maçonnerie</li>
                            <li>Restauration des dommages</li>
                            <li>Terrasses et garde-corps</li>
                            <li>Services de porte</li>
                            <li>Services électriques</li>
                            <li>Sol</li>
                            <li>Entreprise générale</li>
                            <li>Construction de maisons</li>
                            <li>Remodelage de la maison</li>
                            <li>Remodelage de la cuisine</li>
                            <li>La peinture</li>
                            <li>Services de plâtre et de cloison sèche</li>
                            <li>Services de plomberie</li>
                            <li>Ajout de chambres</li>
                            <li>Revêtement</li>
                            <li>Services Windows</li>
                        </ul>
                    </div>
                    <div class="col-md-4 we-serve">
                        <div class="col-md-12 col-sm-12 text-center">
                            <h3>NOUS SERVONS</h3>
                        </div>
                        <ul>
                            <li>Laval</li>
                            <li>Terrebonne</li>
                            <li>Montréal</li>
                            <li>Blainville</li>
                            <li>Boisbriand</li>
                            <li>Saint-Eustache</li>
                            <li>Sainte-Marthe-sur-le-Lac</li>
                            <li>Saint Laurent</li>
                            <li>Repentigny</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- CONTENT END -->

       
</div>
<?php include("includes/footer.php"); ?>