<!DOCTYPE html>
<html lang="en-US"> 
<head> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="apple-touch-icon" sizes="180x180" href="icon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="icon/favicon-16x16.png">
<link rel="manifest" href="icon/site.webmanifest">

<title>Renov Adam</title>
<meta name="description" content="Renov Adam">
<meta name="keywords" content="Renov Adam">

<meta name="author" content="http://www.renovadam.com/" />
<meta name="robots" content="index, follow" />
<meta name="rating" content="safe for kids" />
<meta name="googlebot" content=" index, follow " />
<meta name="allow-search" content="yes" />
<meta name="revisit-after" content="daily" />
<meta name="language" content="en-US" />
<meta name="distribution" content="global" />
<link rel="canonical" href="http://www.renovadam.com/" />

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
<!-- GOOGLE FONTS -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
<!-- [if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
<![endif] -->
</head>
<body>

<div class="page-wraper"> 
   	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="./">French</a></li>
                            <li><a href="../">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
        <!-- Slider -->
        <div class="main-slider">
       		<img src="images/slider.gif">
        </div>
        <!-- Slider END -->
       
        <!-- ABOUT COMPANY SECTION START -->
        <div class="section-full p-tb100 bg-bottom-left bg-no-repeat">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-5">
                        <div class="about-com-pic">
                            <img src="images/about-pic.jpg" alt="" class="img-responsive"/>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7">
                        <div class="section-head welcome-to">
                            <h2>Des rénovations à effectuer? Nous pouvons t'aider!</h2>
                            <div class="wt-separator-outer">
                                <div class="wt-separator style-square">
                                    <span class="separator-left bg-primary"></span>
                                    <span class="separator-right bg-primary"></span>
                                </div>
                            </div>
                            <p>Renov Adam est une entreprise de rénovation domiciliaire située à Laval, au Québec et qui dessert l'ensemble de la région de Montréal depuis de nombreuses années. Adam se spécialise dans la peinture, le plâtrage, la rénovation de cuisine et de salle de bain, la finition du sous-sol, le revêtement de sol et l'installation et bien plus encore. Étaient une entreprise bien établie avec plus de 15 ans d'expertise inégalée. Les préférences et les priorités des clients sont toujours prioritaires. Nous avons été très opportuns avec notre travail et ne perdez jamais l'attention aux détails. Renov Adam s'est bâti une réputation de travail de qualité avec chaque client satisfait.</p>
                            <p>Le choix d'un entrepreneur est le choix le plus important que vous ferez dans tout projet de rénovation. Dans le cas où vous êtes comme la plupart des propriétaires, vous avez probablement eu des réflexions sur les changements et les améliorations à votre maison depuis le jour où vous l'avez. Avec l'aide d'un spécialiste, vous pouvez vous concentrer sur les subtilités qui posent problème: le choix des matériaux, l'élaboration d'un plan et la collaboration avec votre entrepreneur à chaque progression du projet de rénovation.</p>
                            <p>Renov Adam a développé des relations clients longue distance à Laval, au Québec, en fonction de notre conviction que la meilleure façon de travailler est véritablement et raisonnablement. Nous sommes déterminés à vous aider à tirer le meilleur parti de votre plus grande spéculation: votre maison. Nous sommes heureux pour notre durée de vie dans une industrie avec des tas de rivalités; il n'est pas surprenant que nous traitions les maisons de nos clients comme si elles étaient les nôtres. Nous acceptons que rejoindre des offres de produits incroyables avec un groupe de spécialistes est la meilleure façon de procéder.</p>
                            <p>Nous sommes fiers de notre travail, tout comme vous êtes fier de votre maison. N'hésitez pas à nous contacter pour nous parler de votre projet!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
        <!-- ABOUT COMPANY SECTION END -->
        
        <!-- SECTION CONTENT -->         
        <div class="section-full p-t80 p-b50 scale-bg-top scale-bg-bottom">
            <div class="container">
                <!-- TITLE START -->
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Nos services de rénovation</h2>
                    <div class="wt-separator-outer">
                       <div class="wt-separator style-square">
                           <span class="separator-left bg-primary"></span>
                           <span class="separator-right bg-primary"></span>
                       </div>
                   </div>
                    <p>Choisissez Renov Adam pour tous vos besoins de rénovation. Nous travaillons avec une équipe d'experts en architecture, design, électriciens, plombiers et autres artisans qualifiés qui livrent un travail impeccable. Nous pouvons donc assembler des cloisons, des charpentes, peindre, refaire vos planchers, vos systèmes électriques et bien plus encore.</p>
                </div>
                <!-- TITLE END -->     
                <div class="section-content service-items">
                    <div class="row">
                    
                        <!-- COLUMNS 1 --> 
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv1.jpg" alt="Additions"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Ajouts</h4>
                                    <p>L'ajout d'un ajout est un moyen simple d'améliorer votre maison. Avec RenovAdam à vos côtés, c'est encore plus facile. Après avoir dessiné ...</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 2 -->
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv2.jpg" alt="Flooring"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Sol</h4>
                                    <p>Nous savons que les revêtements de sol constituent la base de tout ce que vous faites chaque jour. C'est le sol solide sous vos pieds, le premier plan ...</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 3 -->
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv3.jpg" alt="Universal Design"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Conception universelle</h4>
                                    <p>Créer le bon espace pour vous-même ou votre proche peut faire toute la différence. Nous pouvons vous fournir une barrière ...</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>

                        <!-- COLUMNS 1 --> 
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv4.jpg" alt="Bathrooms"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Salles de bain</h4>
                                    <p>La salle de bain est l'une des pièces les plus importantes de la maison d'un propriétaire et USA Home Improvements Corp.</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 3 -->
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv5.jpg" alt="Kitchens"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Cuisines</h4>
                                    <p>La famille qui mange ensemble, reste ensemble et profite d'un délicieux repas. Avec une toute nouvelle cuisine, la famille ...</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 2 -->
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="services.php"><img src="images/serv6.jpg" alt="Plumbing"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0">Plomberie</h4>
                                    <p>Alors que de nombreuses organisations annoncent chaque minute des services de plomberie de crise quotidiens, trouver un expert ...</p>
                                    <a href="services.php" class="site-button outline black"><strong class="text-center">Lire la suite</strong></a>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                </div>

            </div>
        </div>
        <!-- SECTION CONTENT END --> 
                          
        <!-- WHY CHOOSE US SECTION START  -->
        <div class="section-full bg-gray p-t80 p-b120 bg-no-repeat bg-left-center" style="background-image:url(images/background/why-choose-pic-2.png);">
        	<div class="container">
                <!-- TITLE START-->
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Pourquoi nous choisir</h2>
                    <div class="wt-separator-outer">
                        <div class="wt-separator style-square">
                            <span class="separator-left bg-primary"></span>
                            <span class="separator-right bg-primary"></span>
                        </div>
                    </div>
                </div>
                <!-- TITLE END-->
                <div class="section-content why-choose no-col-gap">
                    <div class="row">
                    
                        <!-- COLUMNS 1 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/no-entry.png" alt="Quality Work"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase">Travail de qualité.</h5>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 5 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/brickwall.png" alt="High Quality Materials"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase">Matériaux de haute qualité.</h5>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 6 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/engineer.png" alt="Skilled Workers"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase">Travailleurs qualifiés.</h5>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 4 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/helmet.png" alt="We surpass ourselves"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase">Nous nous surpassons.</h5>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 3 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/compass.png" alt="Work on time and on budget"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase">Travaillez dans les délais et le budget.</h5>
                                </div>
                            </div>
                        </div>
                        <!-- COLUMNS 2 -->
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="services.php" class="icon-cell"><img src="images/icon/light-bulb.png" alt="Superior Knowledge"></a>
                                </div>
                                <div class="icon-content ">
                                    <h5 class="wt-tilte text-uppercase">Connaissance supérieure.</h5>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- WHY CHOOSE US SECTION END  --> 
        
       
        <!-- SECTION CONTENT START --> 
        <div class="section-full bg-white bg-img-fix p-t80 p-b50 scale-bg-top">
        
            <div class="container">
                    
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Témoignages</h2>
                    <div class="wt-separator-outer">
                        <div class="wt-separator style-square">
                            <span class="separator-left bg-primary"></span>
                            <span class="separator-right bg-primary"></span>
                        </div>
                    </div>
                </div>
                <!-- TESTIMONIAL GRID STYLE 4 -->    
                <div class="section-content">
                    <div class="testimonial-grid">
                            
                        <div class="col-md-4 m-b30">
                            <div class="testimonial-grid-4 testimonial-bg">
                                <div class="testimonial-text clearfix">
                                    <div class="testimonial-paragraph">
                                        <p>Service excellent. Adam a complètement terminé mon sous-sol et j'étais tellement content des résultats. Il est rapide mais méticuleux. Très honnête, professionnel et compétent. Je le recommande vivement! Il ne vous décevra pas.</p>
                                    </div>
                                </div>
                                <div class="testimonial-detail clearfix">
                                    <span class="fa fa-quote-left"></span>
                                    <strong class="testimonial-name">- Ana M.</strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 m-b30">
                            <div class="testimonial-grid-4 testimonial-bg">
                                <div class="testimonial-text clearfix">
                                    <div class="testimonial-paragraph">
                                        <p>Renov Adam a installé des parements de bois et des moulures de fenêtre le long de la façade de notre maison et nous ne pourrions être plus heureux. Ils étaient des professionnels à chaque étape du processus: une excellente communication, un travail de qualité et tout gardé propre et bien rangé. Cela s'est avéré exactement comme nous le voulions.</p>
                                    </div>
                                </div>
                                <div class="testimonial-detail clearfix">
                                    <span class="fa fa-quote-left"></span>
                                    <strong class="testimonial-name">- Lorraine B.</strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 m-b30">
                            <div class="testimonial-grid-4 testimonial-bg">
                                <div class="testimonial-text clearfix">
                                    <div class="testimonial-paragraph">
                                        <p>Très honnête, professionnel et travailleur. Ils ont respecté le budget, respecté notre calendrier, et maintenant nos deux salles de bains sont incroyables et je ne pourrais pas être plus heureux.</p>
                                    </div>
                                </div>
                                <div class="testimonial-detail clearfix">
                                    <span class="fa fa-quote-left"></span>
                                    <strong class="testimonial-name">- Felicia N.</strong>
                                </div>
                            </div>
                        </div>   
                                               
                    </div>
                </div>
                
            </div>
            
        </div>
        <!-- SECTION CONTENT END -->   
    </div>
    <!-- CONTENT END -->
    
    
          
</div>
<?php include("includes/footer.php"); ?>