(function ($) {
	
    'use strict';
/*--------------------------------------------------------------------------------------------
	document.ready ALL FUNCTION START
---------------------------------------------------------------------------------------------*/	

//  > Top Search bar Show Hide function by = custom.js =================== //	
	 function site_search(){
			jQuery('a[href="#search"]').on('click', function(event) {                    
			jQuery('#search').addClass('open');
			jQuery('#search > form > input[type="search"]').focus();
		});
					
		jQuery('#search, #search button.close').on('click keyup', function(event) {
			if (event.target === this || event.target.className === 'close') {
				jQuery(this).removeClass('open');
			}
		});  
	 }	
// > Video responsive function by = custom.js ========================= //	

	function video_responsive(){	
		jQuery('iframe[src*="youtube.com"]').wrap('<div class="embed-responsive embed-responsive-16by9"></div>');
		jQuery('iframe[src*="vimeo.com"]').wrap('<div class="embed-responsive embed-responsive-16by9"></div>');	
	}  

	

// > magnificPopup function	by = magnific-popup.js =========================== //

	function magnific_popup(){
        jQuery('.mfp-gallery').magnificPopup({
          delegate: '.mfp-link',
          type: 'image',
          tLoading: 'Loading image #%curr%...',
          mainClass: 'mfp-img-mobile',
          gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0,1] // Will preload 0 - before current, and 1 after the current image
          },
          image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
          }
       });
	}

// > magnificPopup for video function	by = magnific-popup.js ===================== //	

	function magnific_video(){	
		jQuery('.mfp-video').magnificPopup({
			type: 'iframe',
		});
	}

// Vertically center Bootstrap modal popup function by = custom.js ==============//

	function popup_vertical_center(){	
		jQuery(function() {
			function reposition() {
				var modal = jQuery(this),
				dialog = modal.find('.modal-dialog');
				modal.css('display', 'block');
				// Dividing by two centers the modal exactly, but dividing by three 
				// or four works better for larger screens.
				dialog.css("margin-top", Math.max(0, (jQuery(window).height() - dialog.height()) / 2));
			}
			// Reposition when a modal is shown
			jQuery('.modal').on('show.bs.modal', reposition);
			// Reposition when the window is resized
			jQuery(window).on('resize', function() {
				jQuery('.modal:visible').each(reposition);
			});
		});
	}

// > Main menu sticky on top  when scroll down function by = custom.js ========== //		

	function sticky_header(){
		if(jQuery('.sticky-header').length){
			var sticky = new Waypoint.Sticky({
			  element: jQuery('.sticky-header')
			})
		}
	}


// > input Placeholder in IE9 function by = custom.js ======================== //	

	function placeholderSupport(){
	/* input placeholder for ie9 & ie8 & ie7 */
		jQuery.support.placeholder = ('placeholder' in document.createElement('input'));
		/* input placeholder for ie9 & ie8 & ie7 end*/
		/*fix for IE7 and IE8  */
		if (!jQuery.support.placeholder) {
			jQuery("[placeholder]").on('focus', function () {
				if (jQuery(this).val() === jQuery(this).attr("placeholder")) jQuery(this).val("");
			}).blur(function () {
				if (jQuery(this).val() === "") jQuery(this).val(jQuery(this).attr("placeholder"));
			}).blur();

			jQuery("[placeholder]").parents("form").on('submit', function () {
				jQuery(this).find('[placeholder]').each(function() {
					if (jQuery(this).val() === jQuery(this).attr("placeholder")) {
						 jQuery(this).val("");
					}
				});
			});
		}
		/*fix for IE7 and IE8 end */
	}	



/*--------------------------------------------------------------------------------------------
    Window on scroll ALL FUNCTION START
---------------------------------------------------------------------------------------------*/

    function color_fill_header() {
        var scroll = $(window).scrollTop();
        if(scroll >= 100) {
            $(".is-fixed").addClass("color-fill");
        } else {
            $(".is-fixed").removeClass("color-fill");
        }
    };	

/*--------------------------------------------------------------------------------------------
	document.ready ALL FUNCTION START
---------------------------------------------------------------------------------------------*/
	jQuery(document).ready(function() {
	// > Top Search bar Show Hide function by = custom.js  		
		site_search(),
	// > Video responsive function by = custom.js 
		video_responsive(),
	// > magnificPopup function	by = magnific-popup.js
		magnific_popup(),
	// > magnificPopup for video function	by = magnific-popup.js
		magnific_video(),
	// > Vertically center Bootstrap modal popup function by = custom.js
		popup_vertical_center();
	// > Main menu sticky on top  when scroll down function by = custom.js		
		sticky_header(),
	// > page scroll top on button click function by = custom.js	
		scroll_top(),
	// > input type file function by = custom.js	 	
		input_type_file_form(),
	// > input Placeholder in IE9 function by = custom.js		
		placeholderSupport(),
	//	> box height match window height according function by = custom.js
		set_height(),
	// > footer fixed on bottom function by = custom.js	
		footer_fixed(),
	// > accordion active calss function by = custom.js ========================= //			
		accordion_active(),
	// > Top cart list Show Hide function by = custom.js =================== //		
		cart_block(),
	// > Nav submenu on off function by = custome.js ===================//
		mobile_nav(),
	// > Home Carousel_1 Full Screen with no margin function by = owl.carousel.js
	    home_carousel_1(),
	//  related with content function by = owl.carousel.js ========================== //
	    blog_related_slider(),
	// Fade slider for home function by = owl.carousel.js ========================== //   
	   aboutus_carousel(),
   //  Blog post Carousel function by = owl.carousel.js ========================== //
	   service_detail_carousel(),
   //  blog Carousel_1 Full Screen with no margin function by = owl.carousel.js ========================== //
	   blog_carousel_1(),
	//  Home4 services Carousel_1 Full Screen with no margin function by = owl.carousel.js ==========================  //  
		Home_services_carousel() ,
	// home4_logo_carousel() function by = owl.carousel.js ========================== //
		home4_logo_carousel()
	}); 

/*--------------------------------------------------------------------------------------------
	Window Load START
---------------------------------------------------------------------------------------------*/
	jQuery(window).on('load', function () {
	// > equal each box function by  = custom.js			
		equalheight(".equal-wraper .equal-col"),
	// > On scroll content animated function by = Viewportchecker.js	
		animate_content(),
	// > skills bar function function by  = custom.js			
		progress_bar_tooltips(),
	// > skills bar function function by  = custom.js		
		progress_bar_width(),
	// > On scroll content animated function by = Viewportchecker.js 			
		select_box_form(),
	// > TouchSpin box function by  = jquery.bootstrap-touchspin.js		
		input_number_form(),
	// > TouchSpin box function by  = jquery.bootstrap-touchspin.js		
		input_number_vertical_form(),
	// > box height match window height according function by = custom.js		
		set_height(),
	// > masonry function function by = isotope.pkgd.min.js		
		masonryBox(),
	// > background image parallax function by = stellar.js	
		bg_image_stellar(),
	// > page loader function by = custom.js		
		page_loader() 
});

 /*===========================
	Window Scroll ALL FUNCTION START
===========================*/

	jQuery(window).on('scroll', function () {
	// > Window on scroll header color fill 
		color_fill_header()
	});
	
/*===========================
	Window Resize ALL FUNCTION START
===========================*/

	jQuery(window).on('resize', function () {
	// > footer fixed on bottom function by = custom.js		 
	 	footer_fixed(),
	// > box height match window height according function by = custom.js
	 	set_height()
	});



})(window.jQuery);