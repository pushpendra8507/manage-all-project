<?php  

include_once 'classes/startup.php';
$core = new Core;


?>


<!DOCTYPE html>
<html lang="en-US"> 
<head> 
<meta charset="utf-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="apple-touch-icon" sizes="180x180" href="icon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="icon/favicon-32x32.png">

<link rel="manifest" href="icon/site.webmanifest">

<title>Renov Adam| Home Renovation Contractors in Laval, QC</title>
<meta name="description" content="Renov Adam provides Top Home Renovation Contractors in Laval, QC, and the surrounding areas. We also offer services such as Kitchen Renovation, bathroom renovation, plumbing, room additions, universal design, renovation services, and much more. Visit us for more info!">
<meta name="keywords" content="Professional Plumbing Services in Laval, QC, Painters in Laval, QC, Painting Services in Laval, QC, Kitchen Renovation in Laval, QC, Bathroom Renovation in Laval, QC, Renovation Services in Laval, QC, Exterior & Interior Painting in Laval, QC, Kitchen and Bathroom Renovation in Laval, QC, Basement Renovation in Laval, QC, Plastering Services in Laval, QC, Flooring Services in Laval, QC, Flooring Installation in Laval, QC, Renovation Contractor in Laval, QC, Home Remodeling in Laval, QC, Kitchen Remodeling in Laval, QC, Bathroom Remodeling in Laval, QC, Room Additions in Laval, QC, Cabinet Painting in Laval, QC, Exterior Painting in Laval, QC, Interior Painting in Laval, QC, Plaster & Drywall Services in Laval, QC, Ceiling & Wall Painting in Laval, QC, Hardwood Floor Installation in Laval, QC, Laminate Floor Installation in Laval, QC, Flooring Service in Laval, QC, Universal Design in Laval, QC, Construction Company in Laval, QC, Cabinetry Services in Laval, QC, Home Decor in Laval, QC, Plumbing Services in Laval, QC, Plumbing Repair in Laval, QC, Plumbing Service in Laval, QC, Bathroom Repair in Laval, QC, Plumbing Replacement in Laval, QC, Commercial Plumbing Services in Laval, QC, Commercial Plumbing Repair in Laval, QC, Interior & Exterior Paint  in Laval, QC, Painting Company in Laval, QC, Commercial Painting in Laval, QC, Residential Painting in Laval, QC, Professional Painting in Laval, QC, Painting Contractors in Laval, QC, House Painting in Laval, QC, Painting Renovations  in Laval, QC, Commercial Services in Laval, QC, Damage Restoration in Laval, QC, Electrical Services in Laval, QC, Door Services in Laval, QC, Home Building in Laval, QC, Windows Services in Laval, QC, Siding Services in Laval, QC, Residential Services in Laval, QC, Carpentry Services in Laval, QC, Renovation Contractors in Laval, QC, Kitchen Renovation Contractors in Laval, QC, Bathroom Renovation Contractors in Laval, QC, Home Renovation Company  in Laval, QC, Home Renovation Services in Laval, QC, Home Improvement Services in Laval, QC, Flooring Installations in Laval, QC, Commercial Renovation in Laval, QC, Home Improvement Company in Laval, QC, Interior Renovation in Laval, QC, Exterior Renovation in Laval, QC">

<meta name="author" content="https://www.renovadam.com/" />
<meta name="robots" content="index, follow" />
<meta name="rating" content="safe for kids" />
<meta name="googlebot" content=" index, follow " />
<meta name="allow-search" content="yes" />
<meta name="revisit-after" content="daily" />
<meta name="language" content="en-US" />
<meta name="distribution" content="global" />
<link rel="canonical" href="https://www.renovadam.com/" />
<meta name="google-site-verification" content="fzeaU-IRLEpOv7sgwB4SoRaWENnKO7zUKnVk7X_isCQ" />

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
<!-- GOOGLE FONTS -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
<!-- [if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
<![endif] -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-BMYNH4VJTZ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-BMYNH4VJTZ');
</script>
</head>
<body>

<div class="page-wraper"> 
   	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="<?php echo SITEURL ?>french">French</a></li>
                            <li><a href="<?php echo SITEURL  ?>">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php include("includes/header.php"); ?>
    </header>
    
    <div class="page-content">
    
        <!-- Slider -->
        <div class="main-slider">
       		<img src="<?php echo SITEURL  ?>images/slider.gif" alt="Painters in Laval, QC">
        </div>
        <?php $welcome_data = $mv_welcome->index(); ?>
        <div class="section-full p-tb100 bg-bottom-left bg-no-repeat">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-5">
                        <div class="about-com-pic">
                            <img src="<?php echo SITEURL  ?><?php echo isset($welcome_data['photourl_1'])? $welcome_data['photourl_1']: '' ?>" alt="Painting Services in Laval, QC" class="img-responsive"/>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7">
                        <div class="section-head welcome-to">
                            <h1><?php echo isset($welcome_data['title'])? $welcome_data['title']: '' ?></h1>
                            <div class="wt-separator-outer">
                                <div class="wt-separator style-square">
                                    <span class="separator-left bg-primary"></span>
                                    <span class="separator-right bg-primary"></span>
                                </div>
                            </div>
                            <p><?php echo isset($welcome_data['description_1'])? $welcome_data['description_1']: '' ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>   

                 <?php $services_data = $programes_data->index($homepage = 1);  ?>
        <div class="section-full p-t80 p-b50 scale-bg-top scale-bg-bottom">
            <div class="container">
                <!-- TITLE START -->
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Our Renovation Services</h2>
                    <div class="wt-separator-outer">
                       <div class="wt-separator style-square">
                           <span class="separator-left bg-primary"></span>
                           <span class="separator-right bg-primary"></span>
                       </div>
                   </div>
                    <p>Choose Renov Adam for all your renovation needs. We work with a team of experts in architecture, design, electricians, plumbers and other skilled craftsmen who deliver impeccable work. We can therefore assemble partitions, frame, paint, redo your floors, your electrical systems and much more.</p>
                </div>
                <!-- TITLE END -->     
                <div class="section-content service-items">
                    <div class="row">
                    
                        <!-- COLUMNS 1 --> 
                        <?php foreach($services_data as $service){ ?>
                        <div class="col-md-4 col-sm-4 p-tb15">
                            <div class="wt-box bg-white">
                                <div class="wt-media">
                                    <a href="<?php echo SITEURL  ?>services.php"><img src="<?php echo SITEURL  ?><?php  echo isset($service['photourl'])? $service['photourl']: '' ?>" alt="<?php  echo isset($service['alt_name'])? $service['alt_name']: '' ?>"></a>
                                </div>
                                <div class="wt-info p-tb30">
                                    <h4 class="wt-title m-t0"><?php  echo isset($service['title'])? $service['title']: '' ?></h4>
                                    <p><?php
                                echo isset($service['description']) ? substr(strip_tags($service['description']), 0, 110) . (strlen($service['description']) > 110 ? '...' : '') : '';
                                ?>
                                </p>
                                    <a href="<?php echo SITEURL  ?>services.php" class="site-button outline black"><strong class="text-center">Read More</strong></a>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        <!-- COLUMNS 2 -->
                       
                    
                    </div>
                </div>

            </div>
        </div>
        <!-- SECTION CONTENT END --> 

                    <?php $quality_data = $quality->index(2); ?>      
        <!-- WHY CHOOSE US SECTION START  -->
        <div class="section-full bg-gray p-t80 p-b120 bg-no-repeat bg-left-center" style="background-image:url(<?php echo SITEURL  ?>images/background/why-choose-pic-2.png);">
        	<div class="container">
                <!-- TITLE START-->
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Why Choose us</h2>
                    <div class="wt-separator-outer">
                        <div class="wt-separator style-square">
                            <span class="separator-left bg-primary"></span>
                            <span class="separator-right bg-primary"></span>
                        </div>
                    </div>
                </div>
                <!-- TITLE END-->
                <div class="section-content why-choose no-col-gap">
                    <div class="row">
                    
                        <!-- COLUMNS 1 -->
                        <?php foreach($quality_data as $qul_data){ ?>
                        <div class="col-md-4 col-sm-6 animate_line">
                            <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                <div class="icon-lg text-primary m-b20">
                                    <a href="<?php echo SITEURL  ?>services.php" class="icon-cell"><img src="<?php echo SITEURL  ?><?php echo isset($qul_data['photourl'])? $qul_data['photourl']: '' ?>" alt="<?php echo isset($qul_data['alt_name'])? $qul_data['alt_name']: '' ?>"></a>
                                </div>
                                <div class="icon-content">
                                    <h5 class="wt-tilte text-uppercase"><?php echo isset($qul_data['title'])? $qul_data['title']: '' ?></h5>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        <!-- COLUMNS 5 -->
                       
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- WHY CHOOSE US SECTION END  --> 
        
       <?php $testimonials = $pr_testimonials->index(); ?>
        <!-- SECTION CONTENT START --> 
        <div class="section-full bg-white bg-img-fix p-t80 p-b50 scale-bg-top">
        
            <div class="container">
                    
                <div class="section-head text-center">
                    <h2 class="text-uppercase">Testimonials</h2>
                    <div class="wt-separator-outer">
                        <div class="wt-separator style-square">
                            <span class="separator-left bg-primary"></span>
                            <span class="separator-right bg-primary"></span>
                        </div>
                    </div>
                </div>
                <!-- TESTIMONIAL GRID STYLE 4 -->    
                <div class="section-content">
                    <div class="testimonial-grid">
                            <?php foreach($testimonials as $testimonial_data){ ?>
                        <div class="col-md-4 m-b30">
                            <div class="testimonial-grid-4 testimonial-bg">
                                <div class="testimonial-text clearfix">
                                    <div class="testimonial-paragraph">
                                        <p><?php echo isset($testimonial_data['description'])? $testimonial_data['description']: '' ?></p>
                                    </div>
                                </div>
                                <div class="testimonial-detail clearfix">
                                    <span class="fa fa-quote-left"></span>
                                    <strong class="testimonial-name"><?php echo isset($testimonial_data['name'])? $testimonial_data['name']: '' ?></strong>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        
                                               
                    </div>
                </div>
                
            </div>
            
        </div>
        <!-- SECTION CONTENT END -->   
    </div>
    <!-- CONTENT END -->
    
    
          
</div>
<?php include("includes/footer.php"); ?>