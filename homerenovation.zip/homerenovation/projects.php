<?php
    include("includes/top-header.php");
?>

<div class="page-wraper">
    	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:<?php echo isset($contact['phone'])? $core->phone_url($contact['phone']): '' ?>"><?php echo isset($contact['phone'])? $contact['phone']: '' ?></a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="<?php echo SITEURL ?>french/projects.php">French</a></li>
                            <li><a href="<?php echo SITEURL  ?>projects.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
    	<!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(<?php echo SITEURL ?>images/background/all.jpg);">
        	<div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Projects</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
        	<div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="<?php echo SITEURL  ?>"><i class="fa fa-home"></i> Home</a></li>
                    <li>Projects</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->         
    <?php $gallery_data = $gallery->index(2); ?>
        <!-- SECTION CONTENT -->
        <div class="projects-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <?php foreach($gallery_data as $gal_data){ ?>
                            <li>
                                <a href="<?php echo SITEURL  ?><?php echo isset($gal_data['photourl'])? $gal_data['photourl']: '' ?>" title="Kitchens" class="fancybox" data-fancybox-group="gallery">
                                    <img src="<?php echo isset($gal_data['photourl'])? $gal_data['photourl']: '' ?>" alt="<?php echo isset($gal_data['alt_name'])? $gal_data['alt_name']: '' ?>">
                                </a>
                            </li>
                            <?php } ?>
                           
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
        <!-- SECTION CONTENT END -->
    </div>
    <!-- CONTENT END -->
</div>
<?php include("includes/footer.php"); ?>