<?php
ob_start();
/*database credentials*/

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','db_homerenovation');
define('SITEURL', 'http://localhost/homerenovation/');
define('SITELOGO', 'http://localhost/homerenovation/images/renovadam-logo.png');

// define('DB_HOST','localhost');
// define('DB_USER','root');
// define('DB_PASSWORD','');
// define('DB_NAME','db_homerenovation');
// define('SITEURL',  'https://www.renovadam.com/');
// define('SITELOGO', 'https://www.renovadam.com/images/renovadam-logo.png');





/*Manage Site Currency */
define('SITE_CURRENCY','$');
/*site title for admin pages*/
define('ADMIN_TITLE','HOME RENOVATIONS');


/** email setting */
define('MAIL_TITLE',"HOME RENOVATIONS");

define('ADMIN_EMAIL','moh_graphics@live.ca');

define('FROM_EMAIL','no-reply@renovadam.com');
define('FROM_NAME','HOME RENOVATIONS');
define('BCC_EMAIL',' pushpendra639263@gmail.com');



/** security settings */
define('SECURITY_KEY','i~am~iron~man');
define('ADMIN_SESSION','mv_admin');
define('ADMIN_SESSION_EMAIL','mv_admin_email');



?>