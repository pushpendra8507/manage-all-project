<html>
<head>
<title>Your Website Has been Suspended</title>

<style>
body {background:#f1f1f1; color:green;}
	.alignment {text-align:center;}
</style>

<body>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h1 class="alignment">wXperts Inc.</h1>
<br>
<h1 class="alignment">Your Website <?php echo $_SERVER['HTTP_HOST']; ?> 
has been Suspended due to Non Payment </h1>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h1 

class="alignment">Kindly contact us to renew the membership. Call us at +1-855 469 6368 OR +1-888 487 3122</h1>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</body>
</head></html>