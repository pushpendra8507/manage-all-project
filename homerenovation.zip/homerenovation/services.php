<?php
include("includes/top-header.php");
?>

<div class="page-wraper">
    	
    <!-- HEADER START -->
    <header class="site-header header-style-8">
        <div class="top-header-new">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul>
                            <li><i class="fa fa-map-marker"></i> <a href="https://goo.gl/maps/Pgdmy94XmosJw2127" target="_blank">Laval, QC</a></li>
                            <li><i class="fa fa-phone"></i> <a href="tel:5147929517">(514) 792-9517</a></li>
                            <li><i class="fa fa-id-card"></i> RBQ # 57493777_01</li>
                            <li><a href="<?php echo SITEURL ?>french/services.php">French</a></li>
                            <li><a href="<?php echo SITEURL ?>services.php">English</a> |</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php include("includes/header.php"); ?>
    </header>
    <!-- HEADER END -->
    
    <!-- CONTENT START -->
    <div class="page-content">
    
    	<!-- INNER PAGE BANNER START --> 
        <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/background/all.jpg);">
        	<div class="overlay-main bg-black opacity-07"></div>
            <div class="container">
                <div class="wt-bnr-inr-entry">
                    <h1 class="text-white">Services</h1>
                </div>
            </div>
        </div>
        <!-- INNER PAGE BANNER END -->
        
        <!-- BREADCRUMB ROW -->                            
        <div class="bg-gray-light p-tb20">
        	<div class="container">
                <ul class="wt-breadcrumb breadcrumb-style-2">
                    <li><a href="<?php echo SITEURL ?>"><i class="fa fa-home"></i> Home</a></li>
                    <li>Services</li>
                </ul>
            </div>
        </div>
        <!-- BREADCRUMB ROW END -->         
        <?php $services_data = $programes_data->index(2);  ?>
        <!-- SECTION CONTENT -->
        <?php foreach($services_data as $service){ ?>
        <section class="new-services-page scale-bg-top scale-bg-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="<?php echo SITEURL ?><?php echo isset($service['photourl'])? $service['photourl']: '' ?>" alt="Additions">
                        <h2><?php echo isset($service['title'])? $service['title']: '' ?></h2>
                        <p><?php echo isset($service['description'])? $service['description']: '' ?></p>
                    </div>
                </div>
            </div>
        </section>
       <?php } ?>
     
        <!-- SECTION CONTENT END -->
    
        <section class="service-list-page">
            <div class="container">
                <div class="row">
                    
                </div>
                <div class="row">
                    <div class="col-md-8 service-list">
                        <div class="col-md-12 col-sm-12 text-center">
                            <h3>WE OFFER VARIOUS SERVICES INCLUDING:</h3>
                        </div>
                        <ul>
                            <li>Bathroom Remodeling</li>
                            <li>Cabinetry</li>
                            <li>Carpentry</li>
                            <li>Commercial Services</li>
                            <li>Concrete &amp; Masonry</li>
                            <li>Damage Restoration</li>
                            <li>Decks &amp; Railing</li>
                            <li>Door Services</li>
                            <li>Electrical Services</li>
                            <li>Flooring</li>
                            <li>General Contracting</li>
                            <li>Home Building</li>
                            <li>Home Remodeling</li>
                            <li>Kitchen Remodeling</li>
                            <li>Painting</li>
                            <li>Plaster &amp; Drywall Services</li>
                            <li>Plumbing Services</li>
                            <li>Room Additions</li>
                            <li>Siding</li>
                            <li>Windows Services</li>
                        </ul>
                    </div>
                    <div class="col-md-4 we-serve">
                        <div class="col-md-12 col-sm-12 text-center">
                            <h3>WE SERVE</h3>
                        </div>
                        <ul>
                            <li>Laval</li>
                            <li>Terrebonne</li>
                            <li>Montreal</li>
                            <li>Blainville</li>
                            <li>Boisbriand</li>
                            <li>Saint-Eustache</li>
                            <li>Sainte-Marthe-sur-le-Lac</li>
                            <li>Saint Laurent</li>
                            <li>Repentigny</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- CONTENT END -->

       
</div>
<?php include("includes/footer.php"); ?>